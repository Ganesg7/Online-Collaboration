package com.coll.OnlineCollaborate.model;

public class Friend {

}
